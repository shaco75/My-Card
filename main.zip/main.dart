import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    Myapp(),
  );
}

// هذا الكلاس انشأتة بواسطة النظام جاهز عن طريق الستيتلس ودجيت
class Myapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.orange[600],
        appBar: AppBar(
          title: Text('My contect'),
          backgroundColor: Colors.grey[800],
        ),
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 55.0,
                backgroundImage: AssetImage('images/EQTF9708.JPEG'),
              ),
              SizedBox(
                height: 2.0,
              ),
              Text(
                'Mohammed Hameed',
                style: TextStyle(
                  fontFamily: 'Bakbakone',
                  fontSize: 24.0,
                  color: Colors.white,
                ),
              ),
              Text(
                'Developer & Designer',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 18.0,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                height: 15.0,
                width: 250.0,
                child: Divider(
                  thickness: 1.5,
                  color: Colors.grey[800],
                ),
              ),
              Card(
                child: ListTile(
                  leading: Icon(
                    Icons.local_phone,
                    size: 22.0,
                    color: Colors.green[600],
                  ),
                  title: Text(
                    '+964 770 459 4580',
                    style: TextStyle(
                      fontSize: 16.0,
                    ),
                  ),
                ),
                margin: EdgeInsets.all(20.0),
              ),
              Card(
                child: ListTile(
                  leading: Icon(
                    Icons.mail,
                    color: Colors.red[700],
                  ),
                  title: Text(
                    'Mohammed_Hameed97@yahoo.com',
                    style: TextStyle(
                      fontSize: 15.5,
                    ),
                  ),
                ),
                margin: EdgeInsets.all(20.0),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
